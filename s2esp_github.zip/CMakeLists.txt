cmake_minimum_required(VERSION 3.18)
project(s2esp)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# ── Dobby (hook library) ───────────────────────────────────────────────────
# Clone: git clone https://github.com/jmpews/Dobby.git deps/Dobby
# and build it, or provide prebuilt libdobby.a
set(DOBBY_DIR "${CMAKE_SOURCE_DIR}/deps/Dobby")
if(EXISTS "${DOBBY_DIR}/include/dobby.h")
    add_subdirectory(${DOBBY_DIR} dobby_build)
    set(DOBBY_INC "${DOBBY_DIR}/include")
    set(DOBBY_LIB dobby)
else()
    # Fallback: expect libdobby.a + dobby.h in deps/
    set(DOBBY_INC "${CMAKE_SOURCE_DIR}/deps/include")
    add_library(dobby_static STATIC IMPORTED)
    set_target_properties(dobby_static PROPERTIES
        IMPORTED_LOCATION "${CMAKE_SOURCE_DIR}/deps/lib/${ANDROID_ABI}/libdobby.a")
    set(DOBBY_LIB dobby_static)
endif()

# ── Main shared library ────────────────────────────────────────────────────
add_library(s2esp SHARED
    src/main.cpp
    src/hooks.cpp
    src/esp.cpp
    src/gui.cpp
)

target_include_directories(s2esp PRIVATE
    src/
    ${DOBBY_INC}
)

target_compile_options(s2esp PRIVATE
    -O2
    -fvisibility=hidden
    -ffunction-sections
    -fdata-sections
    -Wno-unused-parameter
)

target_link_options(s2esp PRIVATE
    -Wl,--gc-sections
    -Wl,--strip-all
)

target_link_libraries(s2esp
    ${DOBBY_LIB}
    log
    android
    EGL
    GLESv2
)
