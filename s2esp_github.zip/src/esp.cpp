#include "esp.h"
#include "unity_structs.h"
#include "math_utils.h"
#include <android/log.h>
#include <dlfcn.h>
#include <vector>
#include <cstring>

#define TAG "S2ESP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

ESPConfig g_ESP;

static uintptr_t g_Base       = 0;
static uintptr_t g_WorldXdu   = 0;   // world interface (xdu)
static uintptr_t g_GameState  = 0;   // beq

// ── Function pointer typedefs ─────────────────────────────────────────────
// bool ovy.nldc(Camera* cam, Vector3 from, float dist, int layerMask)
typedef bool (*FnLineOfSight)(uintptr_t cam, Vector3 from, float dist, int mask);
// float ovy.fetz(ActorPtr, int boneIndex)
typedef float (*FnFetz)(uintptr_t actor, int bone);
// bool aie.jtlx(byte teamA, byte teamB)
typedef bool (*FnJtlx)(uint8_t a, uint8_t b);
// Vector2 vpi.qltg(Camera*, Vector3 worldPos)
typedef Vector2 (*FnQltg)(uintptr_t cam, Vector3 worldPos);

static FnLineOfSight fnLineOfSight = nullptr;
static FnFetz        fnFetz        = nullptr;
static FnJtlx        fnJtlx        = nullptr;
static FnQltg        fnQltg        = nullptr;

// ── Camera pointer (set by hook) ──────────────────────────────────────────
uintptr_t g_Camera = 0;

// ── Statics ───────────────────────────────────────────────────────────────
static std::vector<ActorInfo> s_Actors;

// ─────────────────────────────────────────────────────────────────────────
// Unity IL2CPP: find static field value via Class->static_fields
// Here we use the pointer chain known from reversing Standoff 2 0.35
// ─────────────────────────────────────────────────────────────────────────

// Traverse pointer chain to reach actor list (psqk) from game-state (beq)
// Chain: GameState(beq) -> psqk(+0x28) -> List<nal> object
static uintptr_t GetActorList(uintptr_t gameState) {
    if (!gameState) return 0;
    return ReadPtr(gameState + OFF_ACTOR_LIST);
}

// IL2CPP List<T>:
//   +0x10 = backing array ptr
//   +0x18 of that array = element[0]
//   +0x0C of list = int _size
static int GetListCount(uintptr_t listObj) {
    if (!listObj) return 0;
    return ReadInt(listObj + 0x0C);
}

static uintptr_t GetListElement(uintptr_t listObj, int idx) {
    uintptr_t arr = ReadPtr(listObj + 0x10);
    if (!arr) return 0;
    return ReadPtr(arr + 0x20 + (uintptr_t)idx * 8);
}

// ── Nickname via uyac() ───────────────────────────────────────────────────
// RVA for uyac is not given; we read the xsux field directly.
// In Standoff 2, nickname string object is at actor + 0x38 (from reversing)
static std::string GetNickname(uintptr_t actor) {
    uintptr_t strObj = ReadPtr(actor + 0x38);
    return ReadUnityString(strObj);
}

// ── Health from PMV ───────────────────────────────────────────────────────
static float GetHealth(uintptr_t actor) {
    // Actor holds a ref to PlayerMarkerView component at +0x50 (empirically)
    uintptr_t pmv = ReadPtr(actor + 0x50);
    if (!pmv) return 100.f;
    return ReadFloat(pmv + OFF_PMV_HEALTH);
}

// ── Team from dqrw ────────────────────────────────────────────────────────
static int GetTeam(uintptr_t actor) {
    // dqrw byte at +0x48
    return (int)ReadByte(actor + 0x48);
}

// ── Local player team ─────────────────────────────────────────────────────
// localPlayer is first element of the list with isLocalPlayer flag (+0x60)
static int g_LocalTeam = -1;

static bool IsLocalPlayer(uintptr_t actor) {
    return ReadByte(actor + 0x60) != 0;
}

// ── LineOfSight check ─────────────────────────────────────────────────────
static bool CheckLoS(const Vector3& worldPos) {
    if (!fnLineOfSight || !g_Camera) return true;
    int mask = ReadInt(g_Camera + LAYER_MASK_OFFSET);
    Vector3 camPos = GetCameraPos();
    return fnLineOfSight(g_Camera, camPos, RAYCAST_DISTANCE, mask);
}

// ── Head position via fetz ───────────────────────────────────────────────
// bone index 7 = head in Standoff 2
static Vector3 GetHeadPos(uintptr_t actor) {
    if (!fnFetz) {
        Vector3 p = ReadVec3(actor + OFF_ACTOR_POSITION);
        p.y += 1.75f;
        return p;
    }
    float headY = fnFetz(actor, 7);
    Vector3 base = ReadVec3(actor + OFF_ACTOR_POSITION);
    return { base.x, headY, base.z };
}

// ─────────────────────────────────────────────────────────────────────────
void ESP_Init(uintptr_t unityBase) {
    g_Base = unityBase;

    fnLineOfSight = reinterpret_cast<FnLineOfSight>(g_Base + RVA_LINE_OF_SIGHT);
    fnFetz        = reinterpret_cast<FnFetz>       (g_Base + RVA_FETZ);
    fnQltg        = reinterpret_cast<FnQltg>       (g_Base + RVA_VPI_QLTG);

    // aie.jtlx — not strictly needed; we use raw byte compare instead
    // but keep pointer for future use
    fnJtlx = nullptr;

    LOGI("ESP_Init: base=0x%lx LOS=0x%lx fetz=0x%lx qltg=0x%lx",
         (unsigned long)g_Base,
         (unsigned long)(g_Base + RVA_LINE_OF_SIGHT),
         (unsigned long)(g_Base + RVA_FETZ),
         (unsigned long)(g_Base + RVA_VPI_QLTG));
}

// ─────────────────────────────────────────────────────────────────────────
void ESP_Update() {
    if (!g_ESP.enabled.load()) {
        s_Actors.clear();
        return;
    }

    // ── Re-resolve game state each frame (ptr may change on map reload) ──
    // xdu static field chain: il2cpp_resolve_icall approach
    // For Standoff 2 0.35 the chain is:
    //   g_Base + 0x4E20A58 -> game singleton -> beq ref
    uintptr_t singleton = ReadPtr(g_Base + 0x4E20A58);
    if (!singleton) return;
    g_GameState = ReadPtr(singleton + 0x18);  // beq

    uintptr_t actorList = GetActorList(g_GameState);
    if (!actorList) return;

    int count = GetListCount(actorList);
    if (count <= 0 || count > 32) return;

    s_Actors.clear();
    s_Actors.reserve(count);

    Vector3 camPos = GetCameraPos();

    for (int i = 0; i < count; ++i) {
        uintptr_t actor = GetListElement(actorList, i);
        if (!actor) continue;

        // Skip local player
        if (IsLocalPlayer(actor)) {
            g_LocalTeam = GetTeam(actor);
            continue;
        }

        int team = GetTeam(actor);

        // Only enemies (different team)
        if (g_LocalTeam >= 0 && team == g_LocalTeam) continue;

        Vector3 feet  = ReadVec3(actor + OFF_ACTOR_POSITION);
        Vector3 head  = GetHeadPos(actor);
        float   dist  = Vec3Dist(camPos, feet);

        if (dist > 200.f) continue;  // out of render range

        Vector2 screenFeet, screenHead;
        if (!WorldToScreen(feet, screenFeet)) continue;
        if (!WorldToScreen(head, screenHead)) continue;

        ActorInfo info;
        info.ptr        = actor;
        info.worldPos   = feet;
        info.headPos    = head;
        info.screenPos  = screenFeet;
        info.screenHead = screenHead;
        info.team       = team;
        info.distance   = dist;
        info.health     = GetHealth(actor);
        info.nickname   = GetNickname(actor);
        info.visible    = g_ESP.visCheck.load() ? CheckLoS(head) : true;

        s_Actors.push_back(info);
    }
}

const std::vector<ActorInfo>& ESP_GetActors() {
    return s_Actors;
}
