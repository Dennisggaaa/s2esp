#pragma once
#include "unity_structs.h"
#include <vector>
#include <atomic>

// ── ESP feature flags ─────────────────────────────────────────────────────
struct ESPConfig {
    std::atomic<bool> enabled     {true};
    std::atomic<bool> showBoxes   {true};
    std::atomic<bool> showNames   {true};
    std::atomic<bool> showHealth  {true};
    std::atomic<bool> visCheck    {true};   // only visible enemies
    std::atomic<bool> showDist    {true};
    std::atomic<bool> showLines   {false};
};

extern ESPConfig g_ESP;

// Colors  (r,g,b,a  0-1)
static constexpr Color COL_ENEMY_VIS   = {1.00f, 0.20f, 0.20f, 1.0f};  // red
static constexpr Color COL_ENEMY_INVIS = {0.90f, 0.60f, 0.00f, 1.0f};  // orange
static constexpr Color COL_HEALTH_FULL = {0.10f, 0.90f, 0.10f, 1.0f};  // green
static constexpr Color COL_HEALTH_LOW  = {0.90f, 0.10f, 0.10f, 1.0f};  // red
static constexpr Color COL_WHITE       = {1.00f, 1.00f, 1.00f, 1.0f};

// ── Public API ────────────────────────────────────────────────────────────
void     ESP_Init(uintptr_t unityBase);
void     ESP_Update();                           // call each frame
const std::vector<ActorInfo>& ESP_GetActors();
