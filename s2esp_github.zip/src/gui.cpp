// gui.cpp — GLES2 overlay: ESP rendering + menu
// Standoff 2 · arm64-v8a · Zygisk

#include "gui.h"
#include "esp.h"
#include "math_utils.h"
#include "text_render.h"
#include <GLES2/gl2.h>
#include <android/log.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <chrono>

#define TAG "S2GUI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── Globals ───────────────────────────────────────────────────────────────
static int   s_W = 1080, s_H = 1920;
static bool  s_Inited    = false;
static bool  s_MenuOpen  = false;

// Double-tap
static float     s_LastTapX  = 0, s_LastTapY = 0;
static long long s_LastTapMs = 0;
static constexpr long long DOUBLE_TAP_MS = 400;

// ── GLSL: solid-color lines / rects ──────────────────────────────────────
static const char* VERT_SRC = R"(
attribute vec2 aPos;
uniform vec2  uScreen;
void main() {
    vec2 ndc = (aPos / uScreen) * 2.0 - 1.0;
    ndc.y = -ndc.y;
    gl_Position = vec4(ndc, 0.0, 1.0);
}
)";
static const char* FRAG_SRC = R"(
precision mediump float;
uniform vec4 uColor;
void main() { gl_FragColor = uColor; }
)";

static GLuint s_Prog = 0, s_VBO = 0;
static GLint  s_ALoc = 0, s_UScr = 0, s_UCol = 0;

// ── Shader helpers ────────────────────────────────────────────────────────
static GLuint CompileShader(GLenum type, const char* src) {
    GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512]; glGetShaderInfoLog(sh, 512, nullptr, buf);
        LOGI("Shader error: %s", buf);
    }
    return sh;
}

static void InitGL() {
    GLuint vs = CompileShader(GL_VERTEX_SHADER,   VERT_SRC);
    GLuint fs = CompileShader(GL_FRAGMENT_SHADER, FRAG_SRC);
    s_Prog = glCreateProgram();
    glAttachShader(s_Prog, vs); glAttachShader(s_Prog, fs);
    glLinkProgram(s_Prog);
    glDeleteShader(vs); glDeleteShader(fs);

    s_ALoc = glGetAttribLocation (s_Prog, "aPos");
    s_UScr = glGetUniformLocation(s_Prog, "uScreen");
    s_UCol = glGetUniformLocation(s_Prog, "uColor");

    glGenBuffers(1, &s_VBO);
    TextRender_Init();
    s_Inited = true;
    LOGI("GL overlay inited %dx%d", s_W, s_H);
}

// ── Low-level draw ────────────────────────────────────────────────────────
static void UseLineProg() {
    glUseProgram(s_Prog);
    glUniform2f(s_UScr, (float)s_W, (float)s_H);
}

static void SetColor(float r, float g, float b, float a=1.f) {
    glUniform4f(s_UCol, r, g, b, a);
}
static void SetColor(const Color& c) { SetColor(c.r, c.g, c.b, c.a); }

static void DrawRaw(const float* v, int n, GLenum mode) {
    glBindBuffer(GL_ARRAY_BUFFER, s_VBO);
    glBufferData(GL_ARRAY_BUFFER, n*2*sizeof(float), v, GL_STREAM_DRAW);
    glEnableVertexAttribArray(s_ALoc);
    glVertexAttribPointer(s_ALoc, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
    glDrawArrays(mode, 0, n);
}

static void DrawLine(float x1,float y1,float x2,float y2){
    float v[]={x1,y1,x2,y2}; DrawRaw(v,2,GL_LINES);
}

static void DrawRect(float x,float y,float w,float h){
    float v[]={x,y,x+w,y, x+w,y,x+w,y+h, x+w,y+h,x,y+h, x,y+h,x,y};
    DrawRaw(v,8,GL_LINES);
}

static void DrawFilledRect(float x,float y,float w,float h,const Color& c){
    float v[]={x,y, x+w,y, x,y+h, x+w,y+h};
    SetColor(c);
    glBindBuffer(GL_ARRAY_BUFFER, s_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(v), v, GL_STREAM_DRAW);
    glEnableVertexAttribArray(s_ALoc);
    glVertexAttribPointer(s_ALoc, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

// Corner-box (3D ESP style)
static void DrawCornerBox(float x,float y,float w,float h){
    float cw=w*0.25f, ch=h*0.20f;
    float r=x+w, b=y+h;
    float v[]={
        x,y,  x+cw,y,  x,y,  x,y+ch,
        r,y,  r-cw,y,  r,y,  r,y+ch,
        x,b,  x+cw,b,  x,b,  x,b-ch,
        r,b,  r-cw,b,  r,b,  r,b-ch,
    };
    DrawRaw(v,16,GL_LINES);
}

// Health bar (left side)
static void DrawHealthBar(float x,float y,float h,float hp){
    float pct  = hp/100.f;
    float barH = h*pct;
    // bg
    SetColor(0.3f,0.0f,0.0f,0.8f);
    DrawRect(x-6,y,4,h);
    // fg
    SetColor(1.f-pct, pct, 0.f, 1.f);
    float by = y+h-barH;
    float v[]={x-5,by, x-3,by, x-3,by, x-3,y+h, x-3,y+h, x-5,y+h, x-5,y+h, x-5,by};
    DrawRaw(v,8,GL_LINES);
}

// Traceline from bottom-center to enemy feet
static void DrawTraceLine(float tx,float ty){
    SetColor(1.f,1.f,1.f,0.5f);
    DrawLine(s_W*0.5f,(float)s_H,tx,ty);
}

// ── Text ──────────────────────────────────────────────────────────────────
static void DrawText(float x,float y,const char* str,float r,float g,float b,float a=1.f,float scale=1.5f){
    TextRender_Draw(x,y,scale,str,r,g,b,a,s_W,s_H);
    UseLineProg();  // restore program
}

// ─────────────────────────────────────────────────────────────────────────
// MENU
// ─────────────────────────────────────────────────────────────────────────
struct Toggle { const char* label; std::atomic<bool>* flag; float ry; };
static Toggle s_Toggles[6];
static int    s_TCount = 0;

static void BuildToggles(){
    s_TCount = 0;
    auto add=[&](const char* l,std::atomic<bool>* f){
        s_Toggles[s_TCount++]={l,f,0};
    };
    add("ESP",        &g_ESP.enabled);
    add("Boxes",      &g_ESP.showBoxes);
    add("Names",      &g_ESP.showNames);
    add("Health",     &g_ESP.showHealth);
    add("Vis Check",  &g_ESP.visCheck);
    add("Tracelines", &g_ESP.showLines);
}

static void DrawMenu(){
    const float MW=240.f, ROW=42.f, PAD=8.f;
    float MH = 36.f + s_TCount*ROW + PAD;
    float MX = (s_W-MW)*0.5f;
    float MY = (s_H-MH)*0.5f;

    // Shadow
    DrawFilledRect(MX+3,MY+3,MW,MH,{0,0,0,0.5f});
    // Panel
    DrawFilledRect(MX,MY,MW,MH,{0.04f,0.04f,0.10f,0.92f});

    // Title bar
    DrawFilledRect(MX,MY,MW,30,{0.10f,0.35f,0.80f,1.f});
    DrawText(MX+8,MY+6,"S2-ESP",1,1,1,1,1.6f);

    SetColor(0.20f,0.60f,1.0f,1.f);
    DrawRect(MX,MY,MW,MH);
    DrawLine(MX,MY+30,MX+MW,MY+30);

    for(int i=0;i<s_TCount;++i){
        float ry = MY+36+i*ROW;
        s_Toggles[i].ry = ry;
        bool on = s_Toggles[i].flag->load();

        Color bg = on ? Color{0.08f,0.28f,0.08f,0.80f}
                      : Color{0.10f,0.10f,0.12f,0.75f};
        DrawFilledRect(MX+PAD, ry, MW-2*PAD, ROW-4, bg);

        // border
        SetColor(on ? 0.15f : 0.35f,
                 on ? 0.85f : 0.35f,
                 on ? 0.15f : 0.35f, 1.f);
        DrawRect(MX+PAD, ry, MW-2*PAD, ROW-4);

        // label
        DrawText(MX+PAD+6, ry+6, s_Toggles[i].label,
                 on ? 0.2f : 0.7f,
                 on ? 0.9f : 0.7f,
                 on ? 0.2f : 0.7f,
                 1.f, 1.5f);

        // checkbox
        float cbx=MX+MW-32, cby=ry+8;
        SetColor(on?0.15f:0.35f, on?0.85f:0.35f, on?0.15f:0.35f, 1.f);
        DrawRect(cbx,cby,16,16);
        if(on) DrawFilledRect(cbx+3,cby+3,10,10,{0.15f,0.90f,0.15f,1.f});
    }
}

static void MenuHitTest(float tx,float ty){
    if(!s_MenuOpen) return;
    const float MW=240.f, ROW=42.f, PAD=8.f;
    float MH=36.f+s_TCount*ROW+PAD;
    float MX=(s_W-MW)*0.5f, MY=(s_H-MH)*0.5f;
    for(int i=0;i<s_TCount;++i){
        float ry=MY+36+i*ROW;
        if(tx>=MX+PAD && tx<=MX+MW-PAD && ty>=ry && ty<=ry+ROW-4){
            s_Toggles[i].flag->store(!s_Toggles[i].flag->load());
            return;
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────
void GUI_Init(int w,int h){
    s_W=w; s_H=h;
    if(!s_Inited) InitGL();
    BuildToggles();
}

bool GUI_IsMenuOpen(){ return s_MenuOpen; }

void GUI_OnTouch(float x,float y){
    using namespace std::chrono;
    auto now=duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
    float cx=s_W*0.5f, cy=s_H*0.5f;
    bool near=fabsf(x-cx)<s_W*0.25f && fabsf(y-cy)<s_H*0.25f;
    if(near && (now-s_LastTapMs)<DOUBLE_TAP_MS){
        s_MenuOpen=!s_MenuOpen;
        s_LastTapMs=0;
    } else {
        s_LastTapMs=now;
    }
    s_LastTapX=x; s_LastTapY=y;
    if(s_MenuOpen) MenuHitTest(x,y);
}

// ─────────────────────────────────────────────────────────────────────────
void GUI_Render(){
    if(!s_Inited) return;

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_DEPTH_TEST);
    glLineWidth(1.8f);

    UseLineProg();

    if(g_ESP.enabled.load()){
        const auto& actors = ESP_GetActors();
        for(const auto& a : actors){
            float sx=a.screenPos.x,  sy=a.screenPos.y;
            float shx=a.screenHead.x,shy=a.screenHead.y;

            float boxH=sy-shy;
            if(boxH<10.f) continue;
            float boxW=boxH*0.55f;
            float bx=sx-boxW*0.5f, by=shy;

            Color col = a.visible ? COL_ENEMY_VIS : COL_ENEMY_INVIS;

            if(g_ESP.showLines.load())  DrawTraceLine(sx,sy);

            if(g_ESP.showBoxes.load()){
                SetColor(col);
                DrawCornerBox(bx,by,boxW,boxH);
            }

            if(g_ESP.showHealth.load())  DrawHealthBar(bx,by,boxH,a.health);

            if(g_ESP.showNames.load() && !a.nickname.empty()){
                float ny = shy-14;
                float nx = sx - (float)a.nickname.size()*4.5f;
                DrawText(nx,ny,a.nickname.c_str(),
                         col.r,col.g,col.b,1.f,1.4f);
            }

            if(g_ESP.showDist.load()){
                char buf[16];
                snprintf(buf,sizeof(buf),"%.0fm",a.distance);
                DrawText(sx-10,sy+4,buf,0.8f,0.8f,0.8f,0.9f,1.3f);
            }
        }
    }

    if(s_MenuOpen) DrawMenu();

    glDisable(GL_BLEND);
    glUseProgram(0);
}
