#pragma once
#include "unity_structs.h"

void GUI_Init(int screenW, int screenH);
void GUI_Render();                   // called each frame inside hooked eglSwapBuffers
void GUI_OnTouch(float x, float y);  // forward touch events here
bool GUI_IsMenuOpen();
