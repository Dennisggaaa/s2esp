#include "hooks.h"
#include "esp.h"
#include "gui.h"
#include "math_utils.h"
#include "unity_structs.h"
#include "dobby.h"

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <cstring>

#define TAG "S2HOOK"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Extern globals defined in math_utils.h ────────────────────────────────
Matrix4x4 g_ViewMatrix;
Matrix4x4 g_ProjMatrix;
int       g_ScreenW = 1080;
int       g_ScreenH = 1920;

extern uintptr_t g_Camera;

// ── Original function pointers ────────────────────────────────────────────
static EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay, EGLSurface) = nullptr;

// Unity Camera.get_projectionMatrix (il2cpp)
// RVA for Standoff 2 0.35:
#define RVA_CAM_GET_PROJ   0x34F1200ull
#define RVA_CAM_GET_VIEW   0x34F12C0ull
#define RVA_CAM_MAIN       0x34F0A00ull  // Camera.get_main
#define RVA_INPUT_GETTOUCH 0x35A4800ull  // Input.GetTouch
#define RVA_TOUCH_PHASE    0x00000010ull  // Touch.phase offset

typedef Matrix4x4 (*FnGetMat)(uintptr_t cam);
typedef uintptr_t (*FnGetCam)();

static uintptr_t  g_UnityBase = 0;
static bool       g_GUIInited = false;

// ── eglSwapBuffers hook ───────────────────────────────────────────────────
static EGLBoolean hooked_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf) {

    // Lazy init GUI once we have an EGL context
    if (!g_GUIInited) {
        EGLint w = 0, h = 0;
        eglQuerySurface(dpy, surf, EGL_WIDTH,  &w);
        eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
        if (w > 0 && h > 0) {
            g_ScreenW = w; g_ScreenH = h;
            GUI_Init(w, h);
            g_GUIInited = true;
            LOGI("GUI inited %dx%d", w, h);
        }
    }

    // Update camera matrices
    if (g_UnityBase) {
        auto fnMain    = reinterpret_cast<FnGetCam>(g_UnityBase + RVA_CAM_MAIN);
        auto fnGetView = reinterpret_cast<FnGetMat>(g_UnityBase + RVA_CAM_GET_VIEW);
        auto fnGetProj = reinterpret_cast<FnGetMat>(g_UnityBase + RVA_CAM_GET_PROJ);

        uintptr_t cam = fnMain();
        if (cam) {
            g_Camera    = cam;
            g_ViewMatrix = fnGetView(cam);
            g_ProjMatrix = fnGetProj(cam);
        }

        // Update actor data
        ESP_Update();
    }

    // Render overlay
    GUI_Render();

    return orig_eglSwapBuffers(dpy, surf);
}

// ── Touch hook ────────────────────────────────────────────────────────────
// Hook ANativeWindow_unlockAndPost or use Unity Input.GetTouch
// Simpler: hook AInputQueue_getEvent at NDK level
#include <android/input.h>

static int32_t (*orig_processInputEvent)(void*, AInputEvent*) = nullptr;

static int32_t hooked_processInputEvent(void* app, AInputEvent* event) {
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        int32_t action = AMotionEvent_getAction(event);
        int32_t atype  = action & AMOTION_EVENT_ACTION_MASK;
        if (atype == AMOTION_EVENT_ACTION_DOWN || atype == AMOTION_EVENT_ACTION_POINTER_DOWN) {
            float tx = AMotionEvent_getX(event, 0);
            float ty = AMotionEvent_getY(event, 0);
            GUI_OnTouch(tx, ty);
        }
    }
    if (orig_processInputEvent)
        return orig_processInputEvent(app, event);
    return 0;
}

// ─────────────────────────────────────────────────────────────────────────
static uintptr_t FindLibBase(const char* name) {
    // Parse /proc/self/maps
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, name)) {
            base = (uintptr_t)strtoull(line, nullptr, 16);
            break;
        }
    }
    fclose(f);
    return base;
}

// ─────────────────────────────────────────────────────────────────────────
void Hooks_Install() {
    // Wait for target library
    for (int i = 0; i < 60; ++i) {
        g_UnityBase = FindLibBase("libunityframework.so");
        if (g_UnityBase) break;
        sleep(1);
    }
    if (!g_UnityBase) {
        LOGE("libunityframework.so not found — aborting");
        return;
    }
    LOGI("libunityframework.so base = 0x%lx", (unsigned long)g_UnityBase);

    ESP_Init(g_UnityBase);

    // Hook eglSwapBuffers
    void* eglLib = dlopen("libEGL.so", RTLD_NOW);
    if (eglLib) {
        void* sym = dlsym(eglLib, "eglSwapBuffers");
        if (sym) {
            DobbyHook(sym,
                      reinterpret_cast<void*>(hooked_eglSwapBuffers),
                      reinterpret_cast<void**>(&orig_eglSwapBuffers));
            LOGI("eglSwapBuffers hooked @ %p", sym);
        }
        dlclose(eglLib);
    }

    // Hook processInputEvent via libandroid
    void* anLib = dlopen("libandroid.so", RTLD_NOW);
    if (anLib) {
        void* sym = dlsym(anLib, "AInputQueue_getEvent");
        if (sym) {
            DobbyHook(sym,
                      reinterpret_cast<void*>(hooked_processInputEvent),
                      reinterpret_cast<void**>(&orig_processInputEvent));
            LOGI("Input hooked @ %p", sym);
        }
        dlclose(anLib);
    }

    LOGI("All hooks installed");
}
