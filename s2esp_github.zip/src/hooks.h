#pragma once

// Install all hooks (eglSwapBuffers + input)
void Hooks_Install();
