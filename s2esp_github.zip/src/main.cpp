// S2-ESP · Zygisk module entry point
// Targets: com.axlebolt.standoff2  (Standoff 2)
// arch:    arm64-v8a
// Unity:   libunityframework.so 0.35

#include "zygisk.hpp"
#include "hooks.h"
#include <android/log.h>
#include <unistd.h>
#include <pthread.h>
#include <cstring>

#define TAG "S2ESP_ZYGISK"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static constexpr const char* TARGET_PKG = "com.axlebolt.standoff2";

// ── Worker thread: waits for Unity, then installs hooks ───────────────────
static void* worker(void*) {
    LOGI("worker started, waiting for libunityframework.so …");
    // small delay to let JNI_OnLoad finish
    sleep(2);
    Hooks_Install();
    LOGI("worker done");
    return nullptr;
}

// ─────────────────────────────────────────────────────────────────────────
class S2ESPModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api* api, JNIEnv* env) override {
        m_api = api;
        m_env = env;
    }

    // Called in app process, before specialization
    void preAppSpecialize(zygisk::AppSpecializeArgs* args) override {
        const char* name = nullptr;
        if (args->nice_name)
            name = m_env->GetStringUTFChars(args->nice_name, nullptr);

        bool target = name && (strstr(name, "standoff2") ||
                               strstr(name, "axlebolt"));
        if (name) m_env->ReleaseStringUTFChars(args->nice_name, name);

        if (!target) {
            // Not our process — disconnect companion, skip everything
            m_api->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
        }
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs*) override {
        // We're inside Standoff 2 — spin up hook thread
        pthread_t tid;
        pthread_create(&tid, nullptr, worker, nullptr);
        pthread_detach(tid);
        LOGI("hook thread spawned in %s", TARGET_PKG);
    }

    void preServerSpecialize(zygisk::ServerSpecializeArgs*) override {
        m_api->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }

private:
    zygisk::Api* m_api = nullptr;
    JNIEnv*      m_env = nullptr;
};

REGISTER_ZYGISK_MODULE(S2ESPModule)
