#pragma once
#include "unity_structs.h"
#include <cmath>

// ── Camera matrices (updated every frame via hook) ────────────────────────
extern Matrix4x4 g_ViewMatrix;
extern Matrix4x4 g_ProjMatrix;
extern int       g_ScreenW;
extern int       g_ScreenH;

// ─────────────────────────────────────────────────────────────────────────

static inline float Vec3Dist(const Vector3& a, const Vector3& b) {
    float dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return sqrtf(dx*dx + dy*dy + dz*dz);
}

static inline Vector3 Vec3Add(const Vector3& a, const Vector3& b) {
    return { a.x+b.x, a.y+b.y, a.z+b.z };
}

// Multiply 4x4 by vec4
static inline Vector4 Mat4MulVec4(const Matrix4x4& m, const Vector4& v) {
    return {
        m.m[0][0]*v.x + m.m[0][1]*v.y + m.m[0][2]*v.z + m.m[0][3]*v.w,
        m.m[1][0]*v.x + m.m[1][1]*v.y + m.m[1][2]*v.z + m.m[1][3]*v.w,
        m.m[2][0]*v.x + m.m[2][1]*v.y + m.m[2][2]*v.z + m.m[2][3]*v.w,
        m.m[3][0]*v.x + m.m[3][1]*v.y + m.m[3][2]*v.z + m.m[3][3]*v.w,
    };
}

// ── WorldToScreen ─────────────────────────────────────────────────────────
// Returns false if point is behind camera
static inline bool WorldToScreen(const Vector3& world, Vector2& out) {
    // Combined view-proj
    // clip = Proj * View * [x,y,z,1]
    Vector4 viewPos = Mat4MulVec4(g_ViewMatrix, {world.x, world.y, world.z, 1.f});
    Vector4 clipPos = Mat4MulVec4(g_ProjMatrix, viewPos);

    if (clipPos.w <= 0.001f) return false;   // behind camera

    // NDC
    float ndcX = clipPos.x / clipPos.w;
    float ndcY = clipPos.y / clipPos.w;

    // Screen coords (origin = top-left)
    out.x = (ndcX  + 1.f) * 0.5f * (float)g_ScreenW;
    out.y = (1.f - ndcY) * 0.5f * (float)g_ScreenH;

    return true;
}

// ── Camera position (extracted from inverse view matrix) ─────────────────
static inline Vector3 GetCameraPos() {
    // ViewMatrix row 3 col 0-2 gives -translation in view space
    // Camera world pos = -R^T * T
    const auto& m = g_ViewMatrix.m;
    return {
        -(m[0][0]*m[0][3] + m[1][0]*m[1][3] + m[2][0]*m[2][3]),
        -(m[0][1]*m[0][3] + m[1][1]*m[1][3] + m[2][1]*m[2][3]),
        -(m[0][2]*m[0][3] + m[1][2]*m[1][3] + m[2][2]*m[2][3]),
    };
}
