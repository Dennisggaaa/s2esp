#pragma once
// ── Lightweight bitmap-font text renderer for GLES2 overlay ───────────────
// Uses a baked 5×7 pixel font for ASCII 32-126.
// Call TextRender_Init() once after GL context is ready.
// Call TextRender_Draw(x, y, scale, str, r, g, b, a) each frame.

#include <GLES2/gl2.h>
#include <cstring>
#include <cstdint>

// 5×7 font: each char is 5 columns of 7 bits (LSB = top row)
// Covers ASCII 32 (' ') through 90 ('Z') + digits
static const uint8_t s_Font5x7[][5] = {
//  col0  col1  col2  col3  col4
    {0x00,0x00,0x00,0x00,0x00},  // 32 space
    {0x00,0x00,0x5F,0x00,0x00},  // 33 !
    {0x00,0x07,0x00,0x07,0x00},  // 34 "
    {0x14,0x7F,0x14,0x7F,0x14},  // 35 #
    {0x24,0x2A,0x7F,0x2A,0x12},  // 36 $
    {0x23,0x13,0x08,0x64,0x62},  // 37 %
    {0x36,0x49,0x55,0x22,0x50},  // 38 &
    {0x00,0x05,0x03,0x00,0x00},  // 39 '
    {0x00,0x1C,0x22,0x41,0x00},  // 40 (
    {0x00,0x41,0x22,0x1C,0x00},  // 41 )
    {0x14,0x08,0x3E,0x08,0x14},  // 42 *
    {0x08,0x08,0x3E,0x08,0x08},  // 43 +
    {0x00,0x50,0x30,0x00,0x00},  // 44 ,
    {0x08,0x08,0x08,0x08,0x08},  // 45 -
    {0x00,0x60,0x60,0x00,0x00},  // 46 .
    {0x20,0x10,0x08,0x04,0x02},  // 47 /
    {0x3E,0x51,0x49,0x45,0x3E},  // 48 0
    {0x00,0x42,0x7F,0x40,0x00},  // 49 1
    {0x42,0x61,0x51,0x49,0x46},  // 50 2
    {0x21,0x41,0x45,0x4B,0x31},  // 51 3
    {0x18,0x14,0x12,0x7F,0x10},  // 52 4
    {0x27,0x45,0x45,0x45,0x39},  // 53 5
    {0x3C,0x4A,0x49,0x49,0x30},  // 54 6
    {0x01,0x71,0x09,0x05,0x03},  // 55 7
    {0x36,0x49,0x49,0x49,0x36},  // 56 8
    {0x06,0x49,0x49,0x29,0x1E},  // 57 9
    {0x00,0x36,0x36,0x00,0x00},  // 58 :
    {0x00,0x56,0x36,0x00,0x00},  // 59 ;
    {0x08,0x14,0x22,0x41,0x00},  // 60 <
    {0x14,0x14,0x14,0x14,0x14},  // 61 =
    {0x00,0x41,0x22,0x14,0x08},  // 62 >
    {0x02,0x01,0x51,0x09,0x06},  // 63 ?
    {0x32,0x49,0x79,0x41,0x3E},  // 64 @
    {0x7E,0x11,0x11,0x11,0x7E},  // 65 A
    {0x7F,0x49,0x49,0x49,0x36},  // 66 B
    {0x3E,0x41,0x41,0x41,0x22},  // 67 C
    {0x7F,0x41,0x41,0x22,0x1C},  // 68 D
    {0x7F,0x49,0x49,0x49,0x41},  // 69 E
    {0x7F,0x09,0x09,0x09,0x01},  // 70 F
    {0x3E,0x41,0x49,0x49,0x7A},  // 71 G
    {0x7F,0x08,0x08,0x08,0x7F},  // 72 H
    {0x00,0x41,0x7F,0x41,0x00},  // 73 I
    {0x20,0x40,0x41,0x3F,0x01},  // 74 J
    {0x7F,0x08,0x14,0x22,0x41},  // 75 K
    {0x7F,0x40,0x40,0x40,0x40},  // 76 L
    {0x7F,0x02,0x0C,0x02,0x7F},  // 77 M
    {0x7F,0x04,0x08,0x10,0x7F},  // 78 N
    {0x3E,0x41,0x41,0x41,0x3E},  // 79 O
    {0x7F,0x09,0x09,0x09,0x06},  // 80 P
    {0x3E,0x41,0x51,0x21,0x5E},  // 81 Q
    {0x7F,0x09,0x19,0x29,0x46},  // 82 R
    {0x46,0x49,0x49,0x49,0x31},  // 83 S
    {0x01,0x01,0x7F,0x01,0x01},  // 84 T
    {0x3F,0x40,0x40,0x40,0x3F},  // 85 U
    {0x1F,0x20,0x40,0x20,0x1F},  // 86 V
    {0x3F,0x40,0x38,0x40,0x3F},  // 87 W
    {0x63,0x14,0x08,0x14,0x63},  // 88 X
    {0x07,0x08,0x70,0x08,0x07},  // 89 Y
    {0x61,0x51,0x49,0x45,0x43},  // 90 Z
};

static GLuint s_FontTex  = 0;
static GLuint s_TextProg = 0;
static GLuint s_TextVBO  = 0;
static GLint  s_tAPos = 0, s_tATex = 0, s_tUTex = 0, s_tUScr = 0, s_tUCol = 0;

// Build 8×8 RGBA texture atlas for chars 32-90 (59 chars, 4 cols × 15 rows)
static void BuildFontTexture() {
    const int COLS  = 16;      // chars per row in atlas
    const int ROWS  = 4;       // rows
    const int CW    = 6;       // cell width  (5 pixels + 1 gap)
    const int CH    = 8;       // cell height (7 pixels + 1 gap)
    const int W     = COLS * CW;
    const int H     = ROWS * CH;

    uint8_t* buf = new uint8_t[W * H]();

    for (int ci = 0; ci < 59; ++ci) {
        int col = ci % COLS;
        int row = ci / COLS;
        int ox  = col * CW;
        int oy  = row * CH;
        for (int x = 0; x < 5; ++x) {
            uint8_t bits = s_Font5x7[ci][x];
            for (int y = 0; y < 7; ++y) {
                if (bits & (1 << y))
                    buf[(oy + y) * W + (ox + x)] = 0xFF;
            }
        }
    }

    glGenTextures(1, &s_FontTex);
    glBindTexture(GL_TEXTURE_2D, s_FontTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, W, H, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, buf);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glBindTexture(GL_TEXTURE_2D, 0);
    delete[] buf;
}

static const char* TEXT_VERT = R"(
attribute vec2 aPos;
attribute vec2 aTex;
uniform vec2 uScreen;
varying vec2 vTex;
void main() {
    vec2 ndc = (aPos / uScreen) * 2.0 - 1.0;
    ndc.y = -ndc.y;
    gl_Position = vec4(ndc, 0.0, 1.0);
    vTex = aTex;
}
)";

static const char* TEXT_FRAG = R"(
precision mediump float;
varying vec2 vTex;
uniform sampler2D uTex;
uniform vec4 uColor;
void main() {
    float a = texture2D(uTex, vTex).r;
    gl_FragColor = vec4(uColor.rgb, uColor.a * a);
}
)";

static GLuint CompileTextShader(GLenum type, const char* src) {
    GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    return sh;
}

static void TextRender_Init_Internal() {
    BuildFontTexture();
    GLuint vs = CompileTextShader(GL_VERTEX_SHADER,   TEXT_VERT);
    GLuint fs = CompileTextShader(GL_FRAGMENT_SHADER, TEXT_FRAG);
    s_TextProg = glCreateProgram();
    glAttachShader(s_TextProg, vs);
    glAttachShader(s_TextProg, fs);
    glLinkProgram(s_TextProg);
    glDeleteShader(vs);
    glDeleteShader(fs);

    s_tAPos = glGetAttribLocation (s_TextProg, "aPos");
    s_tATex = glGetAttribLocation (s_TextProg, "aTex");
    s_tUScr = glGetUniformLocation(s_TextProg, "uScreen");
    s_tUTex = glGetUniformLocation(s_TextProg, "uTex");
    s_tUCol = glGetUniformLocation(s_TextProg, "uColor");

    glGenBuffers(1, &s_TextVBO);
}

static bool s_TextInited = false;

static void TextRender_Init() {
    if (!s_TextInited) {
        TextRender_Init_Internal();
        s_TextInited = true;
    }
}

// Draw string at (x,y) screen coords (top-left origin).
// scale: pixel size multiplier (1.0 = 5×7 px)
static void TextRender_Draw(float x, float y, float scale,
                            const char* str,
                            float r, float g, float b, float a,
                            int screenW, int screenH) {
    if (!s_TextInited || !str || !str[0]) return;

    const int COLS = 16;
    const int CW_T = 96, CH_T = 32;   // atlas pixel dims (COLS*6, 4*8)
    const float cellW = (float)6 / CW_T;
    const float cellH = (float)8 / CH_T;

    const float gw = 6.f * scale;
    const float gh = 8.f * scale;

    // Build quad buffer  (6 verts per char, 4 floats each = pos2+uv2)
    static float vbuf[512 * 6 * 4];
    int   nverts = 0;
    float px = x;

    for (int i = 0; str[i] && i < 512; ++i) {
        int ci = (int)(uint8_t)str[i] - 32;
        if (ci < 0 || ci >= 59) { px += gw; continue; }

        int col  = ci % COLS;
        int row  = ci / COLS;
        float u0 = (float)(col * 6)     / CW_T;
        float u1 = (float)(col * 6 + 5) / CW_T;
        float v0 = (float)(row * 8)     / CH_T;
        float v1 = (float)(row * 8 + 7) / CH_T;

        float x0 = px,      y0 = y;
        float x1 = px + gw, y1 = y + gh;

        float* q = &vbuf[nverts * 4];
        // tri 1
        q[0]=x0; q[1]=y0; q[2]=u0; q[3]=v0; q+=4;
        q[0]=x1; q[1]=y0; q[2]=u1; q[3]=v0; q+=4;
        q[0]=x0; q[1]=y1; q[2]=u0; q[3]=v1; q+=4;
        // tri 2
        q[0]=x1; q[1]=y0; q[2]=u1; q[3]=v0; q+=4;
        q[0]=x1; q[1]=y1; q[2]=u1; q[3]=v1; q+=4;
        q[0]=x0; q[1]=y1; q[2]=u0; q[3]=v1;
        nverts += 6;
        px += gw;
    }

    if (!nverts) return;

    glUseProgram(s_TextProg);
    glUniform2f(s_tUScr, (float)screenW, (float)screenH);
    glUniform4f(s_tUCol, r, g, b, a);
    glUniform1i(s_tUTex, 0);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, s_FontTex);

    glBindBuffer(GL_ARRAY_BUFFER, s_TextVBO);
    glBufferData(GL_ARRAY_BUFFER, nverts * 4 * sizeof(float), vbuf, GL_STREAM_DRAW);

    glEnableVertexAttribArray(s_tAPos);
    glEnableVertexAttribArray(s_tATex);
    glVertexAttribPointer(s_tAPos, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)0);
    glVertexAttribPointer(s_tATex, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(2*sizeof(float)));

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDrawArrays(GL_TRIANGLES, 0, nverts);

    glDisableVertexAttribArray(s_tAPos);
    glDisableVertexAttribArray(s_tATex);
    glBindTexture(GL_TEXTURE_2D, 0);
    glUseProgram(0);
}
