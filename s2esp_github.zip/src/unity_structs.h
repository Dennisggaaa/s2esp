#pragma once
#include <cstdint>
#include <string>
#include <vector>

// ── Standoff 2 · UnityFramework 0.35 · arm64-v8a ──────────────────────────
// All RVAs are relative to libunityframework.so base address

#define RVA_LINE_OF_SIGHT      0x35444ECull   // ovy.nldc
#define RVA_FETZ               0x3544BD4ull   // ovy.fetz()
#define RVA_MARKER_GNUC        0x37102D0ull   // qbi.gnuc
#define RVA_MARKER_CFG_GIIY    0x37112ECull   // giiy
#define RVA_VPI_QLTG           0x35C2908ull   // vpi.qltg (project points)

// ── Actor field offsets ────────────────────────────────────────────────────
#define OFF_ACTOR_TEAM         0x00          // dqrw  (byte)
#define OFF_ACTOR_NICKNAME     0x00          // xsux  (resolved via uyac())
#define OFF_ACTOR_POSITION     0x18          // fqje  (Vector3)

// ── World / game state ────────────────────────────────────────────────────
// xdu = world interface ptr
// beq = game state
// psqk = actor list;  base + 0x28 = count / first element

#define OFF_ACTOR_LIST         0x28

// ── PlayerMarkerView field offsets ────────────────────────────────────────
#define OFF_PMV_CT_COLOR       0x84
#define OFF_PMV_T_COLOR        0x94
#define OFF_PMV_ENEMY_COLOR    0xA4
#define OFF_PMV_HEALTH         0xB8

// ── Layer mask used by LineOfSight raycast ───────────────────────────────
// logd @ +0x10
#define LAYER_MASK_OFFSET      0x10
#define RAYCAST_DISTANCE       300.0f

// ─────────────────────────────────────────────────────────────────────────
struct Vector2 { float x, y; };
struct Vector3 { float x, y, z; };
struct Vector4 { float x, y, z, w; };

struct Color {
    float r, g, b, a;
};

struct Matrix4x4 {
    float m[4][4];
};

struct ActorInfo {
    uintptr_t ptr;
    Vector3   worldPos;
    Vector3   headPos;
    std::string nickname;
    float     health;        // 0-100
    int       team;          // 0 = CT, 1 = T
    bool      visible;
    Vector2   screenPos;
    Vector2   screenHead;
    float     distance;
};

// ── Helpers ────────────────────────────────────────────────────────────────

static inline uintptr_t ReadPtr(uintptr_t addr) {
    if (!addr) return 0;
    return *reinterpret_cast<uintptr_t*>(addr);
}

static inline float ReadFloat(uintptr_t addr) {
    if (!addr) return 0.f;
    return *reinterpret_cast<float*>(addr);
}

static inline int32_t ReadInt(uintptr_t addr) {
    if (!addr) return 0;
    return *reinterpret_cast<int32_t*>(addr);
}

static inline uint8_t ReadByte(uintptr_t addr) {
    if (!addr) return 0;
    return *reinterpret_cast<uint8_t*>(addr);
}

static inline Vector3 ReadVec3(uintptr_t addr) {
    if (!addr) return {0,0,0};
    return *reinterpret_cast<Vector3*>(addr);
}

static inline std::string ReadUnityString(uintptr_t strObj) {
    // Unity IL2CPP System.String layout:
    // +0x10 = int32 length
    // +0x14 = char16_t chars[]
    if (!strObj) return "";
    int len = ReadInt(strObj + 0x10);
    if (len <= 0 || len > 64) return "";
    std::string result;
    result.reserve(len);
    auto* chars = reinterpret_cast<uint16_t*>(strObj + 0x14);
    for (int i = 0; i < len; ++i)
        result += (char)(chars[i] & 0x7F);
    return result;
}
