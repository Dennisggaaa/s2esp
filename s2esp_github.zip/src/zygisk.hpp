// zygisk.hpp — official Zygisk API header (v4)
// Source: https://github.com/topjohnwu/Zygisk-Next
// Included verbatim for self-contained build.

#pragma once
#include <jni.h>
#include <stdint.h>
#include <stddef.h>

#define ZYGISK_API_VERSION 4

namespace zygisk {

struct AppSpecializeArgs {
    jint  &uid;
    jint  &gid;
    jintArray  &gids;
    jint  &runtime_flags;
    jint  &mount_external;
    jstring &se_info;
    jstring &nice_name;
    jstring &instruction_set;
    jstring &app_data_dir;
    jboolean *const is_child_zygote;
    jboolean *const is_top_app;
    jobjectArray *const pkg_data_info_list;
    jobjectArray *const whitelisted_data_info_list;
    jboolean *const mount_data_dirs;
    jboolean *const mount_storage_dirs;
    AppSpecializeArgs() = delete;
};

struct ServerSpecializeArgs {
    jint &uid;
    jint &gid;
    jintArray &gids;
    jint &runtime_flags;
    jlong &permitted_capabilities;
    jlong &effective_capabilities;
    ServerSpecializeArgs() = delete;
};

class Api;

class ModuleBase {
public:
    virtual void onLoad(Api*, JNIEnv*) {}
    virtual void preAppSpecialize(AppSpecializeArgs*) {}
    virtual void postAppSpecialize(const AppSpecializeArgs*) {}
    virtual void preServerSpecialize(ServerSpecializeArgs*) {}
    virtual void postServerSpecialize(const ServerSpecializeArgs*) {}
    virtual ~ModuleBase() = default;
};

enum class Option : int {
    DLCLOSE_MODULE_LIBRARY = 0,
    FORCE_DENYLIST_UNMOUNT = 1,
};

class Api {
public:
    void setOption(Option opt);
    void  exemptFd(int fd);
    bool  connectCompanion();
    int   getModuleDir();
};

} // namespace zygisk

#define REGISTER_ZYGISK_MODULE(clazz) \
    extern "C" __attribute__((visibility("default"))) \
    zygisk::ModuleBase* zygisk_module_entry(zygisk::Api* api, JNIEnv* env) { \
        auto* m = new clazz(); \
        m->onLoad(api, env); \
        return m; \
    }
